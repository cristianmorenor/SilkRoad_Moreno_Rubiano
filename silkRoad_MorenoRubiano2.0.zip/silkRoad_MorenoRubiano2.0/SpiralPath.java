public class SpiralPath {
    private int step;
    private int direction;
    private int segmentLength;
    private int segmentPassed;

}
